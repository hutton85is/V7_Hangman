#include <iostream>
#include "UIHangmanGame.h"

using namespace std;

int main()
{
    UIHangmanGame game;

//    hangmanGame game(10);

    return 0;
}
